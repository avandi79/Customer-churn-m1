# Customer Churn Prediction (Machine Learning)

This project uses a RandomForest model to predict customer churn.

## Steps
1. Download the dataset:
   https://raw.githubusercontent.com/blastchar/telco-customer-churn/master/WA_Fn-UseC_-Telco-Customer-Churn.csv
2. Place it next to churn.py
3. Run the script in PyCharm.

## Technologies
Python, NumPy, Pandas, Scikit-learn, Matplotlib
